#!/usr/bin/python
# Copyright: (c) 2026, Roman Rel <roman.rel@example.org>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: my_own_module

short_description: Создаёт или обновляет файл с заданным содержимым

description:
  - Модуль создаёт файл по указанному пути, записывает содержимое, устанавливает права, владельца и группу.
  - Поддерживает check_mode.
  - Не использует SELinux-атрибуты, чтобы избежать ошибок в нестабильных версиях Ansible.

options:
    path:
        description: Путь к файлу.
        required: true
        type: str
    content:
        description: Содержимое файла.
        required: false
        type: str
        default: ''
    mode:
        description: Права доступа к файлу в восьмеричном виде (например, "0644").
        required: false
        type: str
        default: '0644'
    owner:
        description: Владелец файла.
        required: false
        type: str
    group:
        description: Группа файла.
        required: false
        type: str
    force:
        description: Принудительно перезаписывать файл, даже если содержимое не изменилось.
        required: false
        type: bool
        default: true

author:
    - Roman Rel (@mrelroman_lang)
'''

EXAMPLES = r'''
- name: Создать файл с содержимым
  my_own_module:
    path: /tmp/test.txt
    content: "Hello world"
    mode: "0644"

- name: Создать файл в режиме проверки
  my_own_module:
    path: /tmp/check.txt
    content: "Check mode"
  check_mode: yes
'''

RETURN = r'''
original_content:
    description: Исходное содержимое файла (если он существовал).
    type: str
    returned: always
    sample: 'Hello world'
new_content:
    description: Новое содержимое файла.
    type: str
    returned: always
    sample: 'Goodbye'
diff:
    description: Различия до/после.
    type: dict
    returned: always
    sample: {'before': 'Hello', 'after': 'Goodbye'}
changed:
    description: Было ли изменение.
    type: bool
    returned: always
    sample: true
'''

import os
import tempfile
import pwd
import grp
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.common.text.converters import to_bytes, to_text


def run_module():
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=False, default=''),
        mode=dict(type='str', required=False, default='0644'),
        owner=dict(type='str', required=False),
        group=dict(type='str', required=False),
        force=dict(type='bool', required=False, default=True),
    )

    result = dict(
        changed=False,
        original_content='',
        new_content='',
        diff=dict(before='', after='')
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']
    mode = module.params['mode']
    owner = module.params['owner']
    group = module.params['group']
    force = module.params['force']

    b_path = to_bytes(path, errors='surrogate_or_strict')
    b_content = to_bytes(content, errors='surrogate_or_strict')

    current_content = ''

    if os.path.exists(b_path):
        try:
            with open(b_path, 'rb') as f:
                current_content_bytes = f.read()
            current_content = to_text(current_content_bytes, errors='surrogate_or_strict')
        except Exception as e:
            module.fail_json(msg=f"Could not read existing file {path}: {e}", **result)

        result['original_content'] = current_content

        if current_content == content and not force:
            module.exit_json(**result)
    else:
        dir_name = os.path.dirname(b_path)
        if dir_name and not os.path.isdir(dir_name):
            if module.check_mode:
                result['changed'] = True
                module.exit_json(**result)
            try:
                os.makedirs(dir_name, exist_ok=True)
            except OSError as e:
                module.fail_json(msg=f"Could not create directory {to_text(dir_name)}: {e}", **result)
        current_content = ''

    result['new_content'] = content
    result['diff']['before'] = current_content
    result['diff']['after'] = content

    if module.check_mode:
        result['changed'] = (current_content != content)
        module.exit_json(**result)

    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp()
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(b_content)
        except Exception:
            os.close(fd)
            raise

        module.atomic_move(tmp_path, b_path)

        # --- Ручная установка атрибутов вместо set_fs_attributes_if_different ---
        if mode is not None:
            try:
                os.chmod(b_path, int(mode, 8))
            except ValueError as e:
                module.fail_json(msg=f"Invalid mode value '{mode}': {e}", **result)

        if owner is not None or group is not None:
            uid = -1
            gid = -1

            if owner is not None:
                try:
                    uid = pwd.getpwnam(owner).pw_uid
                except KeyError:
                    module.fail_json(msg=f"Owner '{owner}' does not exist", **result)

            if group is not None:
                try:
                    gid = grp.getgrnam(group).gr_gid
                except KeyError:
                    module.fail_json(msg=f"Group '{group}' does not exist", **result)

            os.chown(b_path, uid, gid)
        # -------------------------------------------------------------------------

        result['changed'] = True
    except Exception as e:
        if tmp_path is not None:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
        module.fail_json(msg=f"Failed to write file {path}: {e}", **result)

    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
